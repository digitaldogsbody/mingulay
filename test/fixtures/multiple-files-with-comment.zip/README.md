# php-ziprangereader
Zipfile parser and range reader
