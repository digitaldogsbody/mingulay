# Mingulay
Zipfile parser and range reader
